package com.cafeteria.views;

import java.awt.*;
import javax.swing.*;
import javax.swing.text.LayeredHighlighter;

public class Cadastrar extends JFrame {
    private JLabel codigoLabel, nomeLabel, precoLabel;
    private JTextField codigo, nome, preco;
    private JButton inserir, editar, excluir, conferir;
    private JPanel panel1, panel2;
    
    public Cadastrar(){
        super("Cadastro - Cafeteria");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        codigoLabel = new JLabel("Código:");
        nomeLabel = new JLabel("Nome:");
        precoLabel = new JLabel("Preço:");
        codigo = new JTextField(12);
        nome = new JTextField(40);
        preco = new JTextField(7);
        inserir = new JButton("Inserir");
        editar = new JButton("Editar");
        excluir = new JButton("Excluir");
        conferir = new JButton("Conferir");
        panel1 = new JPanel();
        panel2 = new JPanel();

        Container janela = getContentPane();
        janela.setLayout(new BorderLayout());

        panel1.setLayout(new GridLayout(3,2));
        panel2.setLayout(new GridLayout(1,4));

        panel1.add(codigoLabel);
        panel1.add(codigo);
        panel1.add(nomeLabel);
        panel1.add(nome);
        panel1.add(precoLabel);
        panel1.add(preco);
        panel2.add(inserir);
        panel2.add(editar);
        panel2.add(excluir);
        panel2.add(conferir);

        janela.add(panel1, BorderLayout.CENTER);
        janela.add(panel2, BorderLayout.SOUTH);

        pack();
    }
    public static void main (String[] args) {
        Cadastrar cadastrar = new Cadastrar();
        cadastrar.setVisible(true);
    }
}

