package com.cafeteria.views;

import java.awt.*;
import javax.swing.*;
import javax.swing.text.LayeredHighlighter;

public class Login extends JFrame{
    private JLabel tituloLabel, usuarioLabel, senhaLabel;
    private JTextField usuario;
    private JPasswordField senha;
    private JButton entrar;
    private JPanel panel1, panel2, panel3;

    public Login(){
        super("Login - Cafeteria");
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        tituloLabel = new JLabel ("Login");
        usuarioLabel = new JLabel ("Usuário:");
        senhaLabel = new JLabel ("Senha:");
        usuario = new JTextField(20);
        senha = new JPasswordField(20);
        entrar = new JButton("Entrar");
        panel1 = new JPanel();
        panel2 = new JPanel();
        panel3 = new JPanel();


        Container janela = getContentPane();
        janela.setLayout(new BorderLayout());

        panel1.setLayout(new FlowLayout());
        panel2.setLayout(new GridLayout(2,2));
        panel3.setLayout(new FlowLayout());

        panel1.add(tituloLabel);
        panel2.add(usuarioLabel);
        panel2.add(usuario);
        panel2.add(senhaLabel);
        panel2.add(senha);
        panel3.add(entrar);

        janela.add(panel1, BorderLayout.NORTH);
        janela.add(panel2, BorderLayout.CENTER);
        janela.add(panel3, BorderLayout.SOUTH);

        pack();

    }
    public static void main (String[] args) {
        Login login = new Login ();
        login.setVisible(true);
    }
}